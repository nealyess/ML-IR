#!/bin/bash

cd ../working_dir/CA-CON-CA/

for (( i=1; i<158; i++)); do
	mv $i.pdb $i.xyz
done


cd ../dipeptide
for (( i=1; i<157; i++)); do
	mv $i.pdb $i.xyz
done
