

import os
import numpy as np
from pandas import DataFrame
import shutil


if not os.path.exists("../working_dir/CA-CON-CA"):
    os.makedirs("../working_dir/CA-CON-CA")  


def del_pdb(path,suffix):
    for root,dirs,files in os.walk(path):
        for name in files:
            if name.endswith(suffix): 
                os.remove(os.path.join(root, name))
                #print ("Delete File: " + os.path.join(root, name))

del_pdb(path="../working_dir/CA-CON-CA",suffix=".pdb")

input_path = '../input/'
peptide_dir=r'../working_dir/CA-CON-CA/'

a=os.listdir(input_path) 
input_pdb=input_path+','.join(a)

peptide_1ine = []
input_pdb_files = open(input_pdb, 'r')

for line in input_pdb_files:
    if line.startswith('ATOM') or line.startswith('TER '): 
        atom_lines =line[13:15]
        ter_lines = line[0:4]
    
        if atom_lines in ["C ", "O ", "N ", "CA"] and line[16] != 'B':     
            peptide_1ine.append(line[0:80])
        
            if atom_lines == "CA":
                peptide_1ine.append(line[0:80]) 

        elif ter_lines in ["TER "]:
            peptide_1ine.append(line[0:4])
input_pdb_files.close()


if peptide_1ine[-1]=="TER ":
    del peptide_1ine[-1]
   

def find_ter_index(target, source_list):
    ter_index = []
    for index, nums in enumerate(source_list):
        if nums == target:
            ter_index.append(index)
    return(ter_index)

ter_index_all=find_ter_index("TER ",peptide_1ine)

k=0
if len(ter_index_all) >= 1:
    for i in ter_index_all:
        j=i-k
        k+=6
        del peptide_1ine[j-3:j+3]
    
del peptide_1ine[0:2] 

peptide_1ine=np.array(peptide_1ine) # list to array
#print(peptide_1ine)
peptide_1ine2=peptide_1ine.reshape(-1,1)  
#print(peptide_1ine2)

peptide_num=int((peptide_1ine2.shape[0]/5))
for i in range(peptide_num): 
    peptide_1ine3=peptide_1ine2[5*i:5*i+5]
    #print(peptide_1ine3)
    #print("----------")
    peptide_1ine3=DataFrame(peptide_1ine3)
    filename=peptide_dir+str(i+1)+'.pdb'
    peptide_1ine3.to_csv(filename,sep='\t',mode='w',header=None,index=None)

def count_peptide(path,suffix):
    num=0
    for root,dirs,files in os.walk(path):
        for name in files:
            if name.endswith(suffix):
                num=num+1
    return num

peptide_num=count_peptide(path="../working_dir/CA-CON-CA",suffix=".pdb")
print("peptide_num:",peptide_num)

print("1.1. finish split_pdb_to_residue.py")


if not os.path.exists("../working_dir/peptide"):
    os.makedirs("../working_dir/peptide")  

if not os.path.exists("../working_dir/dipeptide"):
    os.makedirs("../working_dir/dipeptide")

def del_pdb(path,suffix):
    for root,dirs,files in os.walk(path):
        for name in files:
            if name.endswith(suffix): 
                os.remove(os.path.join(root, name))
                #print ("Delete File: " + os.path.join(root, name))

del_pdb(path="../working_dir/peptide",suffix=".pdb")
del_pdb(path="../working_dir/dipeptide",suffix=".pdb")

input_path = '../input/'
peptide_dir=r'../working_dir/peptide/'
dipeptide_dir=r'../working_dir/dipeptide/'

a=os.listdir(input_path) #获取input_path所有文件
input_pdb=input_path+','.join(a)

peptide_1ine = []
input_pdb_files = open(input_pdb, 'r')


for line in input_pdb_files:
    if line.startswith('ATOM') or line.startswith('TER '): 

        atom_lines =line[13:15]
        ter_lines = line[0:4]
    
        if atom_lines in ["C ", "O ", "N ","CA"] and line[16] != 'B':     
            peptide_1ine.append(line[0:80])
        
        elif ter_lines in ["TER "]:
            peptide_1ine.append(line[0:4])
input_pdb_files.close()


if peptide_1ine[-1]!="TER ":
    peptide_1ine.insert(-1,"TER ")
peptide_1ine.insert(0,"TER ")

def find_ter_index(target, source_list):
    ter_index = []
    for index, nums in enumerate(source_list):
        if nums == target:
            ter_index.append(index)
    return(ter_index)

ter_index_all=find_ter_index("TER ",peptide_1ine)

n=1 #二胎初始值
p=1 #肽键初始值
for i in range(len(ter_index_all)-1):
    if i != len(ter_index_all):
        j=ter_index_all[i]
        k=ter_index_all[i+1]
        peptide_chain=peptide_1ine[j+3:k-3] #拆分链
        peptide_chain_num = int((len(peptide_chain)-3)/4) #计算对应的链中二肽个数
        
        for l in range(peptide_chain_num):

            #拆分二肽  
            m = 4*l
            dipeptide_temp=np.array(peptide_chain[m:m+7])#拆分二肽
            dipeptide_temp_DF=DataFrame(dipeptide_temp)
            dipeptide_name=dipeptide_dir+str(n)+'.pdb'
            dipeptide_temp_DF.to_csv(dipeptide_name,sep='\t',mode='w',header=None,index=None)
            n=n+1

            #拆分肽键，对于肽键，每条链个数比二肽多一个
            if l != peptide_chain_num-1:#如果不是链的最后一个二肽，则肽键这二肽起点相同
                peptide_temp=np.array(peptide_chain[m:m+3])#拆分肽键
                peptide_name=peptide_dir+str(p)+'.pdb'
                DataFrame(peptide_temp).to_csv(peptide_name,sep='\t',mode='w',header=None,index=None)
                p = p+1
                
            elif l == peptide_chain_num-1:#如果是链的最后一个二肽，则对应两个肽键
                peptide_temp=np.array(peptide_chain[m:m+3])#拆分肽键
                peptide_name=peptide_dir+str(p)+'.pdb'
                DataFrame(peptide_temp).to_csv(peptide_name,sep='\t',mode='w',header=None,index=None)
                p = p+1
                peptide_temp=np.array(peptide_chain[m+4:m+7])#拆分肽键
                peptide_name=peptide_dir+str(p)+'.pdb'
                DataFrame(peptide_temp).to_csv(peptide_name,sep='\t',mode='w',header=None,index=None)
                p = p+1
            

#拆分的肽键的个数
def count_residue(path,suffix):
    num=0
    for root,dirs,files in os.walk(path):
        for name in files:
            if name.endswith(suffix):
                num=num+1
    return num

peptide_num=count_residue(path="../working_dir/peptide",suffix=".pdb")
dipeptide_num=count_residue(path="../working_dir/dipeptide",suffix=".pdb")
print("peptide_num:",peptide_num,"\tpeptide_num:",dipeptide_num)

print("1.1. finish split_pdb_to_pept.py")


