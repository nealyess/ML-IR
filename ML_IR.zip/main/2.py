import numpy as np
import pandas as pd
from pandas import DataFrame
from dscribe.descriptors import CoulombMatrix

#atomic_numbers = [1, 8]
#rcut = 6.0
#nmax = 8
#lmax = 6

# Setting up the CM descriptor
cm = CoulombMatrix(
    n_atoms_max=5,
)

# Creation
from ase.io import read,write
#acsf_peptide_all = np.arange(1,25,dtype=np.int)
for i in range(1,158):
	path=r'./working_dir/CA-CON-CA'
	filename=path+'/'+'zhen'+str(i)+'.xyz'
	peptide = read(filename)
	acsf_peptide1 = cm.create(peptide)
#	acsf_peptide2 = acsf_peptide1.reshape(1,-1)
#	print(acsf_peptide1)
	cm_nma=DataFrame(np.array(acsf_peptide1))
#	print(cm_gldp)
	cm_nma.to_csv('peptide_descriptors.txt',mode='w',header=False,index=False)
#	np.savetxt('gldp_cm.csv',delimiter=',')
#	print(acsf_peptide2.shape)
#	acsf_peptide_all = np.vstack((acsf_peptide_all,acsf_peptide2))
#	print(acsf_peptide2)	
#	print(acsf_peptide2.shape)
#	np.savetxt('gldp_cm.csv',acsf_peptide1,delimiter=',')

# Setting up the CM descriptor
cmm = CoulombMatrix(
    n_atoms_max=9,
)

# Creation
from ase.io import read,write
#acsf_peptide_all = np.arange(1,25,dtype=np.int)
for i in range(1,158):
	path=r'./working_dir/CA-CON-CA'
	filename=path+'/'+'zhen'+str(i)+'.xyz'
	peptide = read(filename)
	acsf_peptide1 = cmm.create(peptide)
#	acsf_peptide2 = acsf_peptide1.reshape(1,-1)
#	print(acsf_peptide1)
	cmm_gldp=DataFrame(np.array(acsf_peptide1))
#	print(cm_gldp)
	cmm_gldp.to_csv('dipeptide_descriptors.txt',mode='w',header=False,index=False)
#	np.savetxt('gldp_cm.csv',delimiter=',')
#	print(acsf_peptide2.shape)
#	acsf_peptide_all = np.vstack((acsf_peptide_all,acsf_peptide2))
#	print(acsf_peptide2)	
#	print(acsf_peptide2.shape)
#	np.savetxt('gldp_cm.csv',acsf_peptide1,delimiter=',')