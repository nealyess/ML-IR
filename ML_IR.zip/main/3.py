import os
import numpy as np
import pandas as pd
from pandas import DataFrame
import joblib
import tensorflow as tf
from sklearn import preprocessing

os.chdir("../working_dir/")

peptide_gzmat=[]
with open("peptide_descriptors.txt", "r") as f:
    for line in f.readlines():
        peptide_gzmat_single = line.strip().split('\n\t')
        for str in peptide_gzmat_single:
            sub_str = str.split(',')
        if sub_str:
            peptide_gzmat.append(sub_str)

#print(peptide_gzmat)
#print(peptide_gzmat.shape)
a=pd.read_csv('peptide_descriptors.txt',sep=',',header=None) #读入txt文件，分隔符为\t
a = a.fillna(0)
peptide_gzmat=np.array(a,dtype=np.float64).reshape(-1,9)
#print(peptide_gzmat)
#print(peptide_gzmat.shape)

#peptide_gzmat=np.array(peptide_gzmat,dtype=np.float64)
#print(peptide_gzmat)
#print(peptide_gzmat.shape)

f.close()

scaler= preprocessing.StandardScaler()
peptide_gzmat = scaler.fit_transform(peptide_gzmat)

def predict(x,model_dir,model_name):
    with tf.compat.v1.Session() as sess:
        init = tf.compat.v1.global_variables_initializer()
        sess.run(init)
    
        # restore saver
        saver = tf.compat.v1.train.import_meta_graph(meta_graph_or_file=model_dir+model_name+".meta")
        saver.restore(sess,model_dir+model_name)
        graph = tf.compat.v1.get_default_graph()
    
        # get placeholder from graph
        xs = graph.get_tensor_by_name("x_inputs:0")
        # get operation from graph
        pred = graph.get_tensor_by_name("pred:0")    
        # run pred
        feed_dict = {xs: x}
        y_test_pred = sess.run(pred,feed_dict=feed_dict)
    
    return y_test_pred

peptide_trans_Enpi = predict(x=peptide_gzmat,model_dir="../main/models/peptide/Enpi/",model_name="freq")
tf.compat.v1.reset_default_graph()

def predict_dip(sub_path,state_name,x):
    dip_x = predict(x,model_dir="../main/models/"+sub_path+"/"+state_name+"x/",model_name=state_name+"x")
    tf.compat.v1.reset_default_graph()
    dip_y = predict(x,model_dir="../main/models/"+sub_path+"/"+state_name+"y/",model_name=state_name+"y")
    tf.compat.v1.reset_default_graph()
    dip_z = predict(x,model_dir="../main/models/"+sub_path+"/"+state_name+"z/",model_name=state_name+"z")
    tf.compat.v1.reset_default_graph()
    dip_xyz=np.hstack((dip_x,dip_y,dip_z))
    return dip_xyz

peptide_trans_Epipi_x = predict_dip(sub_path="peptide",state_name="Edip_npi",x=peptide_xyz)
peptide_trans_Epipi_y = predict_dip(sub_path="peptide",state_name="Edip_pipi",x=peptide_xyz)
peptide_trans_Epipi_z = predict_dip(sub_path="peptide",state_name="Edip_pipi",x=peptide_xyz)

#把两个Enpi,Epipi交叉放到一个文件
#peptide_trans_E = []
#for i in range(peptide_trans_Enpi.shape[0]):
#    peptide_trans_E.append(peptide_trans_Enpi[i])
#    peptide_trans_E.append(peptide_trans_Epipi[i])

#peptide_trans_E=DataFrame(10000000/np.array(peptide_trans_E).reshape(-1,1))
#print(DataFrame(peptide_trans_Enpi.reshape(-1,1)))
peptide_trans_Enpi=DataFrame(peptide_trans_Enpi)
#print(DataFrame(peptide_trans_Enpi))
#print(peptide_trans_Enpi.reshape(-1,1))

peptide_trans_Enpi.to_csv('peptide_freq_ML.txt',mode='w',header=False,index=False)#保存预测结果
residue_dip=np.array([peptide_trans_Epipi_x,peptide_trans_Epipi_y,peptide_trans_Epipi_z])
residue_dip=DataFrame(residue_dip).T
#print(residue_dip)
#print(residue_dip.T)
residue_dip.to_csv('peptide_tran_dip_ML.txt',mode='a',sep='\t',header=False,index=False)
#residue_dip.to_csv('peptide_tran_dip_ML.csv',mode='a',sep='\t',header=False,index=False)

print("3.2.1 finish ML prediction_for_peptide_with_gzmat.py")


