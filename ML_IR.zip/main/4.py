import os
import numpy as np
import pandas as pd
from pandas import DataFrame
import joblib
import tensorflow as tf
from sklearn import preprocessing

os.chdir("../working_dir/")

peptide_gzmat=[]
with open("dipeptide_descriptors.txt", "r") as f:
    for line in f.readlines():
        peptide_gzmat_single = line.strip().split('\n\t')
        for str in peptide_gzmat_single:
            sub_str = str.split(',')
        if sub_str:
            peptide_gzmat.append(sub_str)

#print(peptide_gzmat)
a=pd.read_csv('dipeptide_descriptors.txt',sep=',',header=None) #读入txt文件，分隔符为\t
a = a.fillna(0)
peptide_gzmat=np.array(a,dtype=np.float64)
#peptide_gzmat=np.array(peptide_gzmat,dtype=np.float64).reshape(-1,8)
#print(peptide_gzmat)
#print(peptide_gzmat.shape)
f.close()

###使用内坐标时，经过测试，不需要进行归一化
#归一化
scaler= preprocessing.MinMaxScaler()
peptide_gzmat = scaler.fit_transform(peptide_gzmat)

def predict(x,model_dir,model_name):
    with tf.compat.v1.Session() as sess:
        init = tf.compat.v1.global_variables_initializer()
        sess.run(init)
    
        # restore saver
        saver = tf.compat.v1.train.import_meta_graph(meta_graph_or_file=model_dir+model_name+".meta")
        saver.restore(sess,model_dir+model_name)
        graph = tf.compat.v1.get_default_graph()
    
        # get placeholder from graph
        xs = graph.get_tensor_by_name("x_inputs:0")
        # get operation from graph
        pred = graph.get_tensor_by_name("pred:0")    
        # run pred
        feed_dict = {xs: x}
        y_test_pred = sess.run(pred,feed_dict=feed_dict)
    
    return y_test_pred

dipeptide_ouhe = predict(x=peptide_gzmat,model_dir="../main/models/peptide/ouhe/",model_name="ouhe")
tf.compat.v1.reset_default_graph()

dipeptide_ouhe=DataFrame(dipeptide_ouhe)
#print(dipeptide_ouhe)
dipeptide_ouhe.to_csv('dipeptide_ML_ouhe.txt',mode='w',header=False,index=False)#保存预测结果
#residue_dip=np.array([peptide_trans_Epipi_x,peptide_trans_Epipi_y,peptide_trans_Epipi_z])
#residue_dip=DataFrame(residue_dip).T
#print(residue_dip)
#print(residue_dip.T)
#residue_dip.to_csv('peptide_tran_dip_ML.txt',mode='a',sep='\t',header=False,index=False)
#residue_dip.to_csv('peptide_tran_dip_ML.csv',mode='a',sep='\t',header=False,index=False)

print("3.2.1 finish ML prediction_for_peptide_with_gzmat.py")