# -*- coding: utf-8 -*-
#该脚本使用机器学习GBR方法,描述符为gzmat(一种内坐标)预测的肽键跃迁能和残基偶极矩计算体系的哈密顿量:Hamil_ML.txt

#计算非对角元部分，需要如下文件
#肽键的跃迁能和质心坐标：peptide_trans_E_ML.txt,peptide_com.txt 
#肽键的跃迁偶极矩：peptide_trans_Edip.txt
#残基的偶极矩和质心坐标: residue_dip_ML.txt, residue_com.txt

import re
import os
import shutil
import numpy as np
import pandas as pd
from pandas import DataFrame


########计算对角元项#############################

#输入肽键的跃迁能
os.chdir("../working_dir")

#输入肽键的振动频率
inputfile1 = open(r"../working_dir/peptide_freq_ML.txt",'r')
dataline1=inputfile1.readlines()
inputfile1.close()
#print(dataline1)
#输入肽键的跃迁偶极矩
inputfile2 = open(r"../working_dir/peptide_tran_dip_ML.txt",'r')
dataline2=inputfile2.readlines()
inputfile2.close()
#输入肽键的质心坐标
inputfile3 = open(r"../working_dir/peptide_com.txt",'r')
dataline3=inputfile3.readlines()
inputfile3.close()

##残基的偶极矩    
#inputfile4 = open(r"../working_dir/residue_dip_ML.txt",'r')
#dataline4=inputfile4.readlines()
#inputfile4.close()
    
##残基的质心坐标
#inputfile5 = open(r"../working_dir/residue_com.txt",'r')
#dataline5 = inputfile5.readlines()
#inputfile5.close()

if os.path.exists("hamil_diagonal.txt"):
        os.remove("hamil_diagonal.txt")    

if os.path.exists("hamil_off_diagonal.txt"):
        os.remove("hamil_off_diagonal.txt")    

print("5.1 finish H_dia")

####Step_2:计算哈密顿量的非对角元##################
#前面已导入数据
#dataline2：肽键跃迁偶极矩
#dataline3:肽键质心

#print("for 1--------------------------------------")
for index1,index2 in zip(range(len(dataline3)),range(len(dataline2))):
#    print("index1,2:",index1,index2)
    coor1 = re.split(r"\s+", dataline3[index1].strip())
    coor_x = float(coor1[0])
    coor_y = float(coor1[1])
    coor_z = float(coor1[2])
    coor_1_1 = [coor_x,coor_y,coor_z]
#    print("coor_1_1:",coor_1_1)
    
    coor2 = re.split(r"\s+", dataline2[index2].strip())
    coor_x = float(coor2[0])
    coor_y = float(coor2[1])
    coor_z = float(coor2[2])
    coor_2_2 = [coor_x,coor_y,coor_z]
#    print("coor_2_2:",coor_2_2)
    
    r_m =  np.array(coor_1_1) 
    u_m = np.array(coor_2_2)
#    print("r_m",r_m)
#    print("u_m",u_m)

    #print("\tfor 2--------------------------------------")
    for index3,index4 in zip(range(len(dataline3)),range(len(dataline2))):
#        print("\tindex3,4:",index3,index4)
        if index3 >= index1:
            coor3 = re.split(r"\s+", dataline3[index3].strip())
            coor_x = float(coor3[0])
            coor_y = float(coor3[1])
            coor_z = float(coor3[2])
            coor_3_3 = [coor_x,coor_y,coor_z]
#            print("\tcoor_3_3:",coor_3_3)
			
            coor4 = re.split(r"\s+", dataline2[index4].strip())
            coor_x = float(coor4[0])
            coor_y = float(coor4[1])
            coor_z = float(coor4[2])
            coor_4_4 = [coor_x,coor_y,coor_z]
#            print("\tcoor_4_4:",coor_4_4)
            r_n =  np.array(coor_3_3)  
            u_n = np.array(coor_4_4)
#            print("r_n",r_n)
#            print("u_n",u_n)
            r_mn = np.linalg.norm(r_n-r_m) #肽键-肽键质心距离，r_mn=sqr[(x2-x1)^2+(y2-y1)^2+(z2-z1)^2]
#            print("\tr_mn^0.5:",r_mn) 
            R_mn =  r_n-r_m #肽键-肽键质心，矢量相减，R_mn=(x2-x1)+(y2-y1)+(z2-z1)
#            print("\tR_mn:",R_mn)
            u_m_r = np.dot(u_m,R_mn) #肽键跃迁偶极矩· 肽键偶极矩
#            print("\tμ_mr·R_mn:",u_m_r) #点乘 μp·Rmn=x1*x2+y1*y2+z1*z2
            u_mn = np.dot(u_m,u_n) #点乘 μp·Rmn=x1*x2+y1*y2+z1*z2
#            print("\tμp·μp:",u_mn)
            u_n_r = np.dot(u_n,R_mn)
#            print("\tμ_nr·R_mn:",u_n_r)
			
            #5034.063626,把au.单位的跃迁能转化为cm-1单位
            if r_mn ==0:
                Jmn="NaN"
                #print("\tJmn:",Jmn)
            else:
                Jmn =((u_mn/(r_mn**3))-3*((u_m_r*u_n_r)/r_mn**5))*5034.063626
                #print("\tJmn:",Jmn)
	
            Jmn = float(Jmn)
#            print("Jmn",Jmn)
            
            with open ("../working_dir/hamil_off_diagonal.txt",'a+') as f:
                f.write("{:>25.8f}".format(Jmn))
        else:
            Jmn=0
            with open ("../working_dir/hamil_off_diagonal.txt",'a+') as f:
                f.write("{:>25.8f}".format(Jmn))
	    
    with open ("../working_dir/hamil_off_diagonal.txt",'a+') as f:
        f.write('\n')
    #print("finish")

f.close()
print("5.2 finish H_off")


####Step_3:合并哈密顿量的对角元+非对角元##################

#说明，上三角下三角应该一样，但是为了简化计算，第二部只计算了上三角，下三角全部为0

inputfile6=np.loadtxt("hamil_off_diagonal.txt")
datafile6_org=DataFrame(inputfile6)

inputfile7=np.loadtxt("../working_dir/peptide_freq_ML.txt")
H_dia=np.ndarray.tolist(inputfile7)

datafile6_t=np.transpose(datafile6_org) #转置矩阵,上三角转为下三角
datafile6_lower=np.tril(datafile6_t,-1) #填充对角元为0
datafile6_lower=DataFrame(datafile6_lower)
H_off=datafile6_lower.replace(0,'') #替换0为空白

H_off=np.array(H_off)
np.fill_diagonal(H_off,H_dia) #填充对角元：把对角元插入非对角元文件，合并

#print(H_off)
lower=np.loadtxt("dipeptide_ML_ouhe.txt")
Hoff=np.fill_diagonal(H_off[1:, :-1], lower)
#print(H_off)

H_off=DataFrame(H_off)
Hamil=H_off.fillna(0) #填充空值为0

#print(Hamil)

###替换副对角元项(二肽耦合项),edit by yess
#Hamil=np.array(Hamil)
#lower=np.array([7,7,7])
#Hamil=np.fill_diagonal(Hamil[1:, :-1], lower)
#Hamil=DataFrame(Hamil)
#print(Hamil)
#Hamil.to_csv('Hamil.csv',mode='a',header=False,index=False)
Hamil.to_csv('Hamil_ML.txt',mode='w',sep='\t',header=False,index=False)

#os.remove("hamil_off_diagonal.txt")
#os.remove("hamil_diagonal.txt")

print("5.2 finish calculation of Himiltonian of ML")

