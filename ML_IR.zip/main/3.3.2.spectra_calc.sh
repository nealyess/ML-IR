#!/bin/bash
#准备input设置文件，计算FUV光谱
#FUV使用speactra计算,需要:Hamil_DFT/ML/NN.txt, peptide_trans_Edip.txt, peptide_com.txt, input_LA_DFT/ML/NN.inp
#生成的光谱结果文件是:$pdb_filename2_sig-LA-DFT/ML/NN.dat

#-----------生成计算光谱需要的input_LA.inp文件-----------
cd ../working_dir
cp ../main/models/spectron_inp/*.inp .
echo -e "\n" > inp_tmp2.inp
echo $(ls |wc -l peptide_com.txt |sed 's/^/NUMMODES    /g' | sed 's/peptide_com.txt//g') >> inp_tmp2.inp
echo -e "\n" >> inp_tmp2.inp

#cat input_LA_DFT1.inp inp_tmp2.inp input_LA3.inp > input_LA_DFT.inp
cat input_LA_ML1.inp inp_tmp2.inp input_LA3.inp > input_LA_ML.inp
#cat input_LA_NN1.inp inp_tmp2.inp input_LA3.inp > input_LA_NN.inp

rm  input_LA_ML1.inp input_LA_DFT1.inp input_LA_NN1.inp inp_tmp2.inp input_LA3.inp 
#rm  input_LA_ML1.inp inp_tmp2.inp input_LA3.inp

#------------计算FUV光谱-------------
#pdb_filename1=$(ls ../input/)
#pdb_filename2=${pdb_filename1%.*}

#/home/hfnl/jxzh/Program/EHEF/spectron -i input_LA_DFT.inp
#mv sig-LA.dat $pdb_filename2'_sig-LA-DFT.dat'
#/home/hfnl/jxzh/Program/EHEF/spectron -i input_LA_ML.inp
#mv sig-LA.dat $pdb_filename2'_sig-LA-ML.dat'
#/home/hfnl/jxzh/Program/EHEF/spectron -i input_LA_NN.inp
#mv sig-LA.dat $pdb_filename2'_sig-LA-NN.dat'
#echo "6.1 finish spectra_calc.sh"


